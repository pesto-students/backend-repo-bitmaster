const mongoose = require('mongoose');
const validator = require('validator');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');


const accountSchema = new mongoose.Schema({
    fullName: {
        type: String,
        required: true,
        trim: true
    },
    emailAddress: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowercase: true,
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new Error('E-mail is invaild')
            }
        }
    },
    phoneNo: {
        type: Number,
        required: true,
        unique: true,
        trim: true,
        validate(value) {
            if (!validator.isMobilePhone(String(value))) {
                throw new Error('Phone No is invaild')
            }
        }
    },

    password: {
        type: String,
        required: true,
        validate(value) {
            if (value.toLowerCase().includes('password')) {
                throw new Error('Password cannot be password');
            }
        },
        minlength: 8,
        trim: true
    }
}, {
    timestamps: true
})

accountSchema.methods.generateWebToken = function () {
    const user = this;
    const token = jwt.sign({ exp: Math.floor(Date.now() / 1000) + (2 * 24 * 60 * 60), data: { _id: user._id.toString() } }, process.env.MY_SECRET);
    return token;
}

accountSchema.methods.toJSON = function () {
    const userObject = this.toObject();

    delete userObject.password;
    delete userObject.tokens;

    return userObject;
}

accountSchema.statics.findByEmail = async (email) => {
    const user = await Account.findOne({ email });
    if (!user) {
        return true
    }
    return false;
}

accountSchema.statics.findByCredentials = async (email, password) => {
    const user = await Account.findOne({ emailAddress:email });
    const response = {};
    if (!user) {
        response.emailError = "Incorrect email Address";
    }else{
        const isCorrect = await bcrypt.compare(password, user.password);
        if (!isCorrect) {
            response.passwordError = "Incorrect password";
        }
    }
    return {user,response};
}

accountSchema.pre('save', async function (next) {
    const user = this;
    if (user.isModified('password')) {
        user.password = await bcrypt.hash(user.password, 8);
    }

    next();
})


const Account = mongoose.model('Account', accountSchema,"Account");

module.exports = Account;
