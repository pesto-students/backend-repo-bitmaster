const mongoose = require('mongoose');

const BlogSchema = new mongoose.Schema({

    blogTitle: {
        type: String,
        required: true
    },
    blogShortDescription: {
        type: String,
        required: true
    },
    writtenBy:{
        type: String,
        required: true
    },
    blogImageUrl:{
        type: String,
        required: true
    },
    blogData:{
        type:Object,
        required:true
    }
}, {
    timestamps: true
})

const blog = mongoose.model('blogs', BlogSchema);

module.exports = blog;