const mongoose = require('mongoose');

const discountSchema = new mongoose.Schema({
    couponCode: {
        type: String,
        required: true,
        trim: true,
        unique: true,
    },
    validTill:{
        type : Date,
        required: true,
    },
    maxUsageCount:{
        type:Number,
        required:true,
    },
    usageCount:{
        type:Number,
        required:true,
    },
    discountType:{
        type:String,
        default:"percent", //else flat
    },
    discountValue:{
        required:true,
        type:Number,
    },
    minOrderValue:{
        required:true,
        type:Number
    }
}, {
    timestamps: true
})

const discount = mongoose.model('discount', discountSchema);

module.exports = discount;
