const mongoose = require('mongoose');

const franchiseQuerySchema = new mongoose.Schema({

    message:{
        type:String,
        minlength: 40, 
        required:true,
    },
    accountId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'Account',
        unique: true,
    },
},{
    timestamps: true
})

const franchiseQuery = mongoose.model('franchiseQuery',franchiseQuerySchema,'franchiseQueries');

module.exports = franchiseQuery;