const mongoose = require('mongoose');

// Define the schema for a menu item
const menuSchema = new mongoose.Schema({
    itemName: {
        type: String,
        required: true
    },
    itemDescription: { 
        type: String, 
        required: true 
    },
    itemPrice: { 
        type: Number, 
        required: true 
    },
    itemType: { 
        type: String, 
        required: true 
    },
    isAvailable: { 
        type: Boolean, 
        default: true 
    },
    itemImageUrl: {
        type: String ,
    },
    emotion: {
        type: String,
    },
    totalOrders: {
        type: Number, 
        default: 0 
    },
    menuItemType:{
        type: String ,
        required: true
    }
},{
    timestamps:true
});

// Create the Menu model
const Menu = mongoose.model('Menu', menuSchema, 'Menu');

module.exports = Menu;
