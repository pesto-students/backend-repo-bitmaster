const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const orderAmountSchema = new Schema({
  totalPriceBeforeTax: {
    type: Number,
    required: true
  },
  totalTax: {
    type: Number,
    required: true
  },
  totalPriceAfterTax: {
    type: Number,
    required: true
  }
},{ _id: false });

module.exports = orderAmountSchema;
