const mongoose = require('mongoose');

const discountDetailsSchema = new mongoose.Schema({
    discountedAmount: {
        type: Number,
        required: true
    },
    discountCouponId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'discount'
    },
    discountType: {
        type: String,
        enum: ['percent', 'flat'], // Add other possible values if applicable
        required: true
    },
    discountValue: {
        type: Number,
        required: true
    },

},{ _id: false })

module.exports = discountDetailsSchema;