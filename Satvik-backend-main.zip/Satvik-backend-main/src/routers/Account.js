const express = require('express')
const router = new express.Router()
const Account = require('../models/Account')

router.post('/signUp', async (req, res) => {
    try {
        const account = await Account.findByEmail(req.body.emailAddress);
        if (account) {
            const accountDetails = new Account({ ...req.body })
            await accountDetails.save();
            const jwt = accountDetails.generateWebToken();
            console.log(jwt);
            res.cookie('uid', jwt)
        }
        res.status(201).send('Cookie has been set');
    } catch (error) {
        res.status(400).send(error)
    }
});

router.post('/login', async (req, res) => {
    try {
        const { user, response } = await Account.findByCredentials(req.body.emailAddress, req.body.password);
        if (Object.keys(response).length === 0) {
            const jwt = user.generateWebToken();
            const expirationDate = new Date();
            expirationDate.setDate(expirationDate.getDate() + 2);
            res.cookie('uid', jwt, {
                expires: expirationDate,
            })
            res.status(201).send('Cookie has been set');
        } else {
            res.status(400).json(response)
        }
    } catch (error) {
        res.status(400).send(error)
    }
});

module.exports = router