const express = require('express')
const router = new express.Router()
const Address = require('../models/Address');
const auth = require('../middleware/auth.js')


router.post("/saveAddress", auth, async (req, res) => {
    try {
        let addressDetails;
        if (req.body?._id) {
            const updatedAddress = {
                ...req.body,
                AccountId: req.user._id
            };
            await Address.findOneAndUpdate(
                { _id: req.body._id },
                updatedAddress,
                { new: true }
            )
            addressDetails = updatedAddress;
        } else {
            addressDetails = new Address({
                ...req.body, AccountId: req.user._id
            });
            addressDetails.save();
        }
        res.status(200).send(addressDetails);
    } catch (error) {
        res.status(400).send(error);
    }
});


router.get("/getAddresses", auth, async (req, res) => {
    try {
        const addresses = await Address.find({ AccountId: { $eq: req.user._id } });
        res.status(200).json(addresses);
    } catch (error) {
        res.status(400).send(error);
    }
});

router.delete('/deleteAddress/:id', auth, async (req, res) => {
    try {
        await Address.deleteOne({
            _id:req.params.id
        });
        res.status(200).send({status:true,message:"deleted successfully"});
    } catch (error) {
        res.status(400).send(error);
    }
})

module.exports = router;