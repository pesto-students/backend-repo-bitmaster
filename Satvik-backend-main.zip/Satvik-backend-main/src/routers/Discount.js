const express = require('express')
const router = new express.Router()
const Discount = require('../models/Discount');
const auth = require('../middleware/auth');

router.get('/validateCoupon/:couponCode/:amountBeforeTax',auth, async (req, res) => {
    try {
        const couponCode = req.params.couponCode;
        const amountBeforeTax = req.params.amountBeforeTax;
        const couponDetials = await Discount.findOne({
            validTill:{$gt:new Date()},
            couponCode:couponCode,
            $expr: { $gt: ['usageCount', 'maxUsageCount'] }
        });
        if(couponDetials){
            const discount={
                discountValue:couponDetials.discountValue,
                discountCouponId:couponDetials._id,
                discountType:couponDetials.discountType,
                discountedAmount:0
            }
            if(amountBeforeTax < couponDetials.minOrderValue){
                res.status(200).json({status:false,message:`Add items worth Rs ${couponDetials.minOrderValue - amountBeforeTax} more to get ${couponDetials.discountType==="percent"?couponDetials.discountValue+"%":"Flat "+couponDetials.discountValue} off`});
            }else{
                res.status(200).json({status:true,message:"Coupon applied",discount});
            }
        }else{
            res.status(400).json({status:false,message:"Invalid Coupon code"});
        }
    } catch (error) {
        res.status(400).send(error)
    }
});

module.exports = router