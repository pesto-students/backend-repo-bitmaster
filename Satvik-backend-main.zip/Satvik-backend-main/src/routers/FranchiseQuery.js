const express = require('express')
const router = new express.Router()
const FranchiseQuery = require('../models/FranchiseQuery.js')
const auth = require('../middleware/auth.js');

router.post("/franchiseQuery", auth, async (req, res) => {
    try {
        const checkQueryExist = await FranchiseQuery.findOne({
            accountId: { $eq: req.user._id }
        });
        if (checkQueryExist) {
            res.status(400).json({ status: false, message: "Your query already exist" })
        } else {
            const franchiseQuery = new FranchiseQuery({
                ...req.body,
                accountId: req.user._id
            })
            await franchiseQuery.save();
            res.status(201).json({ status: true})
        }
    } catch (error) {
        res.status(400).send(error);
    }
});

router.get('/queryExist',auth, async(req,res)=>{
    try {
        const checkQueryExist = await FranchiseQuery.findOne({
            accountId: { $eq: req.user._id }
        });
        if (checkQueryExist) {
            res.status(200).json({exist:true})
        }else{
            res.status(200).json({exist:false})
        }
    } catch (error) {
        res.status(400).send(error);
    }
});

module.exports = router;