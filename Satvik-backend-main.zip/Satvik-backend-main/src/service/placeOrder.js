const Menu = require('../models/Menu');
const Order = require('../models/order')

async function placeOrder(OrderData) {
    let response = {
        status:true,
        message:""
    }
    try {
        const items = [...await getItems(OrderData)];
        const { paymentMode, specialInstruction, orderedBy ,address } = OrderData;

        const orderDetails = new Order({
            items: items,
            paymentMode,
            specialInstruction,
            orderedBy,
            ...(OrderData.discountDetials?.discount ? { discountDetails: OrderData.discountDetials.discount } : {}),
            orderAmounts: { ...OrderData.orderAmounts },
            address
        })
        await orderDetails.save();
    } catch (error) {
        console.log(error);
        response.status = false;
        response.message = error;
    }
    return response;
}

async function getItems(OrderData) {
    let items = []
    let itemsNotAvailable = [];
    const itemIds = OrderData.items.map((item) => item.itemId);
    const foodItems = await Menu.find({ _id: { $in: itemIds } });

    for (const item of OrderData.items) {
        for (const itemsDetails of foodItems) {
            if (item.itemId === String(itemsDetails._doc._id)) {
                if (itemsDetails._doc.isAvailable) {
                    items.push({
                        ...item,
                        pricePerItem: itemsDetails._doc.itemPrice,
                        itemName: itemsDetails._doc.itemName,
                        itemType:itemsDetails._doc.itemType,
                        totalPrice: itemsDetails._doc.itemPrice * item.quantity,
                    })
                } else {
                    itemsNotAvailable.push({ ...item });
                }
            }
        }
    }
    return items;
}


module.exports = placeOrder;